# n8n Free FFmpeg Renderer v3

Designed for a small Render instance:
- one render at a time
- one FFmpeg thread
- 720x1280 output
- 24 fps
- ultrafast H.264
- accepts n8n `movie.scenes` format
- POST /render
- GET /status/:id
- GET /files/:id/final.mp4
- GET /health

Deploy to Render as a Python Web Service.
