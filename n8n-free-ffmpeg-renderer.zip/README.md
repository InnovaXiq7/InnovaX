# n8n Free FFmpeg Renderer

Microservicio HTTP para que n8n mande 3 clips y reciba un MP4 vertical.

## Flujo

n8n -> POST /render -> job id -> GET /status/{id} -> GET /files/{id}/final.mp4

## Importante

Este proyecto NO es magia de hosting gratuito: FFmpeg necesita CPU/RAM.
Para que n8n funcione con el PC apagado, este contenedor debe estar desplegado en
un servicio/servidor accesible públicamente. Si se ejecuta en tu PC, n8n debe
poder acceder a tu PC y este debe estar encendido.

## Payload

{
  "scenes": [
    {"video_url":"https://...","audio_url":"https://..."},
    {"video_url":"https://..."},
    {"video_url":"https://..."}
  ]
}

audio_url es opcional. En esta versión, si existe, se usa la primera pista como
audio global. Para voz individual por escena hay que ampliar el montaje con
FFmpeg.

## Endpoints

GET /health
POST /render
GET /status/{job_id}
GET /files/{job_id}/final.mp4
