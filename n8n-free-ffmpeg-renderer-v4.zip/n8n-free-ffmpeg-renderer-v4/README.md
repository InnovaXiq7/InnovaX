# n8n Free FFmpeg Renderer v4

Render service for n8n on Render.

Supports:
- POST /render
- GET /status/:id
- GET /files/:id/final.mp4
- POST /upload-audio (multipart field: `file`)
- GET /files/audio/:filename
- GET /health

The renderer accepts 3 scenes. Each scene may contain:
- a video element: `{ "type": "video", "src": "..." }`
- an audio element: `{ "type": "audio", "src": "..." }`

When an audio URL is present, FFmpeg downloads it, muxes it with the scene video, and the final MP4 keeps the audio track.

## n8n flow
1. ElevenLabs generates MP3 as binary `data`.
2. HTTP Request POST to `/upload-audio` using multipart field `file` and binary property `data`.
3. Use the returned `public_url` as the scene's `audio.src`.
4. POST the movie/scenes to `/render` as before.
